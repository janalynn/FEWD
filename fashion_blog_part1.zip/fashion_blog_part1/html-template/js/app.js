var App = function(){


  this.init = function(){

    console.log('App online.');

  };

};

App.init();
